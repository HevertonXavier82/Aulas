package Herenca01;

public class Carro extends Veiculo {
    private  int Numportas;
	public Carro( String marca, String modelo, int Numportas) {
		super( marca,modelo);
		this.Numportas = Numportas;
	}
    
	public void ligarFarol() {
		System.out.println("Farol do carro ligado.");
	}
	
	
}
