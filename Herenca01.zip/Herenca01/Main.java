package Herenca01;

public class Main {

	public static void main(String[] args) {
	 Carro meucarro = new Carro ("FIAT","UNO",2);
	 Moto minhamoto = new Moto ("HONDA","Biz", 125);
	 
	 meucarro.acelerar();
	 meucarro.ligarFarol();
	 
	 minhamoto.acelerar();
	 minhamoto.empinar();

	}

}
