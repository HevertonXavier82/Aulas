package Heranca;

public class Main {

	public static void main(String[] args) {
		Cachorro cachorro = new Cachorro("Rex");
        cachorro.fazerSom(); // Chamando o método da classe pai
        cachorro.latir();    // Chamando o método da classe filha

	}

}
